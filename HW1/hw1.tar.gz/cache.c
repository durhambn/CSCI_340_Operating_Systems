
// -----------------------------------
// CSCI 340 - Operating Systems
// Fall 2018
// cache.c file
// 
// Homework 1
//
// -----------------------------------

#include "cache.h"
#include "memory.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int initializeCache( unsigned int number_of_lines ) {

	int line, retVal;

	retVal = OK;

	cache = malloc( sizeof( cache_line ) * number_of_lines );

	if ( cache != NULL ) {

		for ( line=0; line<number_of_lines; line++ ) {

			cache[line] = (cache_line*) malloc( sizeof( cache_line ) );
			cache[line]->tag = UNK;
			cache[line]->hit_count = ZERO;

		}

	} else
		retVal = FAIL;

	return retVal;

} // end initializeCache function


int cread( unsigned int cmf, unsigned int* hex_addr, unsigned int* found, unsigned int* replace ) {

	/* TODO: You complete


	*/

	int retVal = OK; // this is simply put here so the code complies, you must code correctly.


	return retVal;

} // end cread function



void cprint() {

	unsigned int line;

	printf("\n---------------------------------------------\n");
	printf("line\ttag\tnum of hits\n");
	printf("---------------------------------------------\n");

	for ( line=0; line<NUM_OF_LINES; line++ ) { 

		if ( cache[line]->tag == UNK ) {
			
			printf("%d\t%d\t%d\n", line, cache[line]->tag, cache[line]->hit_count );

		} else {

			printf("%d\t%02X\t%d\n", line, cache[line]->tag, cache[line]->hit_count );

		}

	}

} // end cprint function
